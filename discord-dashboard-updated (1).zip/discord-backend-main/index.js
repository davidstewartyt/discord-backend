const express = require('express');
const session = require('express-session');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3010;
const DISCORD_API = 'https://discord.com/api/v10';
const required = ['DISCORD_CLIENT_ID', 'DISCORD_CLIENT_SECRET', 'DISCORD_REDIRECT_URI', 'SESSION_SECRET'];
const missing = required.filter((key) => !process.env[key]);

if (missing.length) {
  console.warn(`Missing environment variables: ${missing.join(', ')}. Configure them before Discord login will work.`);
}

app.set('trust proxy', 1);
app.use(express.json());
app.use(session({
  name: 'discord_dashboard_session',
  secret: process.env.SESSION_SECRET || 'development-only-change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, 'static')));

function configured(res) {
  if (missing.length) {
    res.status(503).json({ error: 'Discord login is not configured on the server yet.', missing });
    return false;
  }
  return true;
}

async function discordRequest(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(body.message || `Discord API returned ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return body;
}

app.get('/auth/discord', (req, res) => {
  if (!configured(res)) return;
  const state = crypto.randomBytes(24).toString('hex');
  req.session.oauthState = state;
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_REDIRECT_URI,
    response_type: 'code',
    scope: 'identify guilds',
    state
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

app.get('/auth/discord/callback', async (req, res) => {
  if (!configured(res)) return;
  const { code, state, error } = req.query;
  if (error) return res.redirect('/?login=cancelled');
  if (!code || !state || state !== req.session.oauthState) {
    delete req.session.oauthState;
    return res.status(400).send('Invalid OAuth state. Please return to the dashboard and try again.');
  }
  delete req.session.oauthState;

  try {
    const tokenData = await discordRequest('https://discord.com/api/v10/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: process.env.DISCORD_REDIRECT_URI
      })
    });
    const user = await discordRequest(`${DISCORD_API}/users/@me`, {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const guilds = await discordRequest(`${DISCORD_API}/users/@me/guilds`, {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });

    req.session.discord = {
      accessToken: tokenData.access_token,
      expiresAt: Date.now() + (tokenData.expires_in * 1000),
      user,
      guilds
    };
    req.session.save(() => res.redirect('/'));
  } catch (err) {
    console.error('Discord OAuth error:', err.message);
    res.redirect('/?login=failed');
  }
});

app.get('/api/me', (req, res) => {
  if (!req.session.discord) return res.status(401).json({ authenticated: false });
  const { user, guilds } = req.session.discord;
  res.json({ authenticated: true, user, guilds });
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('discord_dashboard_session', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
    res.json({ ok: true });
  });
});

app.get('/health', (_req, res) => res.json({ status: 'online' }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'pages', 'index.html')));

app.listen(PORT, '0.0.0.0', () => console.log(`Discord dashboard running on port ${PORT}`));
