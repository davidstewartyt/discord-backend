# Discord Dashboard

A small Express app that signs users in with Discord OAuth2 and displays their Discord profile and the servers their account belongs to.

## Requirements
- Node.js 18+
- A Discord application created in the [Discord Developer Portal](https://discord.com/developers/applications)
- A public HTTPS deployment URL (Render works)

## Discord application setup
1. Create an application in the Discord Developer Portal.
2. Open **OAuth2** and add this exact callback URL: `https://YOUR-RENDER-SERVICE.onrender.com/auth/discord/callback`.
3. Copy the Application ID and Client Secret.
4. Add these environment variables to your Render service:

| Variable | Value |
|---|---|
| `DISCORD_CLIENT_ID` | Your Discord Application ID |
| `DISCORD_CLIENT_SECRET` | Your Discord OAuth2 Client Secret |
| `DISCORD_REDIRECT_URI` | `https://YOUR-RENDER-SERVICE.onrender.com/auth/discord/callback` |
| `SESSION_SECRET` | A long random secret (do not share it) |
| `NODE_ENV` | `production` |

The redirect URI in Render must exactly match the one in the Developer Portal.

## Run locally
```bash
npm install
DISCORD_CLIENT_ID=your_id DISCORD_CLIENT_SECRET=your_secret DISCORD_REDIRECT_URI=http://localhost:3010/auth/discord/callback SESSION_SECRET=replace_this npm start
```
Then open `http://localhost:3010`.

## What this version can access
- The signed-in user's basic Discord profile (`identify` scope).
- The list of servers the signed-in user belongs to (`guilds` scope).

It does **not** read DMs, private channels, or server messages. To display channels and messages, create and install a Discord bot in each server and use the bot API with appropriate server permissions and message intents. Never use a user account token or a self-bot. This starter intentionally does not expose OAuth access tokens to browser JavaScript.

## Deployment
Render can use **Build Command** `npm install` and **Start Command** `npm start`. Set the environment variables above in the Render dashboard, then deploy.
