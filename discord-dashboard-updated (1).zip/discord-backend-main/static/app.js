const serversEl = document.querySelector('#servers');
const sidebarContent = document.querySelector('#sidebar-content');
const content = document.querySelector('#content');
const accountBar = document.querySelector('#account-bar');
const pageTitle = document.querySelector('#page-title');
const logoutButton = document.querySelector('#logout');

function avatarUrl(user, size = 128) {
  if (user.avatar) return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=${size}`;
  const index = Number(BigInt(user.id) >> 22n) % 6;
  return `https://cdn.discordapp.com/embed/avatars/${index}.png`;
}
function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}
function showError(message) {
  content.innerHTML = `<div class="notice"><h2>Couldn’t connect</h2><p>${escapeHtml(message)}</p><a class="connect-button" href="/auth/discord">Try again</a></div>`;
}
function renderHome(user, guilds) {
  const displayName = user.global_name || user.username;
  const avatar = avatarUrl(user, 256);
  accountBar.innerHTML = `<img class="avatar" src="${avatar}" alt=""><div class="account-text"><strong>${escapeHtml(displayName)}</strong><small>@${escapeHtml(user.username)}</small></div><button id="logout" class="icon-button" title="Log out">↪</button>`;
  document.querySelector('#logout').addEventListener('click', logout);

  serversEl.innerHTML = `<div class="discord-mark">D</div><div class="server-divider"></div>` + guilds.slice(0, 30).map((guild, i) => `<button class="server-button ${i === 0 ? 'selected' : ''}" data-guild="${escapeHtml(guild.id)}" title="${escapeHtml(guild.name)}">${guild.icon ? `<img src="https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=96" alt="">` : `<span>${escapeHtml((guild.name || '?').slice(0, 2).toUpperCase())}</span>`}</button>`).join('');
  sidebarContent.innerHTML = `<div class="muted-label">YOUR SERVERS · ${guilds.length}</div>` + (guilds.length ? guilds.map(g => `<button class="guild-row" data-guild="${escapeHtml(g.id)}"><span class="guild-dot"></span>${escapeHtml(g.name)}</button>`).join('') : '<p class="sidebar-hint">Your account is not currently in any servers.</p>') + `<p class="permission-note">Server names are from your Discord account. Channel contents need a bot installed in each server.</p>`;
  content.innerHTML = `<div class="profile-card"><img class="profile-avatar" src="${avatar}" alt=""><div><p class="eyebrow">CONNECTED DISCORD ACCOUNT</p><h1>${escapeHtml(displayName)}</h1><p class="profile-tag">@${escapeHtml(user.username)}${user.discriminator && user.discriminator !== '0' ? `#${escapeHtml(user.discriminator)}` : ''}</p></div></div><div class="stats-grid"><div class="stat-card"><span>Servers</span><strong>${guilds.length}</strong></div><div class="stat-card"><span>Account ID</span><strong class="id-value">${escapeHtml(user.id)}</strong></div><div class="stat-card"><span>Connection</span><strong class="connected">Connected</strong></div></div><div class="section-heading"><h2>Your servers</h2><span>${guilds.length} found</span></div><div class="server-grid">${guilds.map(g => `<div class="server-card">${g.icon ? `<img src="https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png?size=128" alt="">` : `<div class="server-placeholder">${escapeHtml((g.name || '?').slice(0, 2).toUpperCase())}</div>`}<div><strong>${escapeHtml(g.name)}</strong><small>${g.owner ? 'You own this server' : 'Member'}</small></div></div>`).join('')}</div><div class="info-banner"><strong>Want real channels and messages?</strong><p>That part needs a Discord bot added to each server with permission to view the channels. This dashboard deliberately does not use a user-token/self-bot.</p></div>`;
  pageTitle.innerHTML = '<span class="hash">#</span> home';
  document.querySelectorAll('[data-guild]').forEach(button => button.addEventListener('click', () => {
    const guild = guilds.find(g => g.id === button.dataset.guild);
    if (!guild) return;
    pageTitle.textContent = guild.name;
    content.innerHTML = `<div class="notice"><h2>${escapeHtml(guild.name)}</h2><p>This server is connected to your account, but its channels and messages are not available through basic account sign-in.</p><p>To display server channels here, install your Discord bot in this server and grant only the permissions it needs.</p></div>`;
  }));
}
async function logout() {
  await fetch('/auth/logout', { method: 'POST' });
  location.href = '/';
}
async function init() {
  const params = new URLSearchParams(location.search);
  if (params.get('login') === 'failed') showError('Discord sign-in did not complete. Check your application settings and redirect URL.');
  if (params.get('login') === 'cancelled') showError('You cancelled Discord sign-in.');
  try {
    const response = await fetch('/api/me');
    if (response.status === 401) return;
    if (!response.ok) throw new Error('The dashboard server returned an error.');
    const data = await response.json();
    renderHome(data.user, data.guilds || []);
  } catch (error) { showError(error.message); }
}
init();
